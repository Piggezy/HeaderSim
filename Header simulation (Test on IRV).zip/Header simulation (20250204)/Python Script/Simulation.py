from OPCGatePy.opc_calc_task import OPCCalcTask
import numpy as np
from scipy.signal import lfilter


class SampleTask(OPCCalcTask):
    def __init__(self, ip, port):
        super(SampleTask, self).__init__(ip, port)
        self.pressures = [0, 0, 0]
        
        # Define nonlinear transfer function models for three boilers.
        model1 = {
            # x = 70 denote 70% load, return efficiency (MPa/g/Kwh).
            "func": lambda x: 1000 / 38 / (0.04568 * (x ** 2) - 7.2013 * x + 650.2371), 
            # "func": lambda x: 1000 / 38 / (0.04568 * (x ** 2) - 8.2013 * x + 650.2371),        
            # Differential equation parameters of the dynamic model
            "A": [1, -1.84392746379236, 0.848654975880398],
            "B": [0, 0.00704085326812763, -0.00670992742196520],
            "delay": 7,
            # Baseline gain of the dynamic model.
            "gain0": 0.07,
            # Real-time gain, differing from baseline gain, varies with load and is computed via func.
            "gain": None,
            # Baseline maximum steam pressure
            "full_ps": 10,
        }

        model2 = {
            "func": lambda x: 1000 / 38 / (0.04568 * (x ** 2) - 7.2045 * x + 530.2443),  
            # "func": lambda x: 1000 / 38 / (0.04568 * (x ** 2) - 8.2013 * x + 650.2371),   
            "A": [1, -1.84392746379236, 0.848654975880398],
            "B": [0, 0.00704085326812763, -0.00670992742196520],
            "delay": 7,
            "gain0": 0.07,
            "gain": None,
            "full_ps": 10,
        }

        model3 = {
            "func": lambda x: 1000 / 38 / (0.04866 * (x ** 2) - 7.3462 * x + 590.2007),
            # "func": lambda x: 1000 / 38 / (0.04568 * (x ** 2) - 8.2013 * x + 650.2371),   
            "A": [1, -1.84392746379236, 0.848654975880398],
            "B": [0, 0.00704085326812763, -0.00670992742196520],
            "delay": 7,
            "gain0": 0.07,
            "gain": None,
            "full_ps": 10,
        }
        self.models = [model1, model2, model3]
        self.model_names = ["model1", "model2", "model3"]
        self.full_load = model1["full_ps"] + model2["full_ps"] + model3["full_ps"]

        self.num_input = 3
        order = 2
        self.low_pass_a = 0
        self.low_pass_b = 1  
        self.U_past = [np.zeros((order + model["delay"], 1))
                       for model in self.models]
        self.Y_past = [np.zeros((order, 1)) for _ in range(3)]

        self.SP_percentage = 65
        # self.SP_total = self.SP_percentage / 100 * (self.models[0]["full_ps"] + self.models[1]["full_ps"] + self.models[2]["full_ps"]) / 3
        self.SP_total = 6.5
        self.write({'static_layer.SP_percentage': self.SP_percentage})
        self.write({'dynamic_layer.SP_total': self.SP_total})
        

    def generate_noises(self):
        """生成多个噪声序列"""
        # 定义滤波器参数
        A = [1, -0.95]
        B = [0.01]
        length = 100000
        seeds = [1, 2, 3]
    
        # 初始化噪声列表
        noises = []
    
        # 遍历每个种子生成对应的噪声序列
        for seed in seeds:
            # 设置随机种子并生成噪声序列
            rng = np.random.default_rng(seed)
            e = rng.standard_normal(length)
            
            # 对噪声序列进行滤波
            filtered_noise = lfilter(B, A, e)
    
            # 保存滤波后的噪声
            noises.append(filtered_noise)
    
        return noises

    def initial_state(self):
        # Initialization
        pressures = {'pressure1': 0, 'pressure2': 0, 'pressure3': 0}
        ov_test_group = {'ov1_test': 0, 'ov2_test': 0, 'ov3_test': 0}
        ov_group = {'ov1': 6.5, 'ov2': 6.5, 'ov3': 6.5}
        irv_values = {'irv1': 6.5, 'irv2': 6.5, 'irv3': 6.5}
        mv_values = {'mv1': 0, 'mv2': 0, 'mv3': 0, 'mv4': self.SP_total, 'mv5': self.SP_total, 'mv6': self.SP_total}
        
        self.v1, self.v2, self.v3 = self.generate_noises()
        
        # Calculate the weighted average of steam pressure
        pressure_weighted = sum(pressures.values()) / len(pressures)
    
        # Calculate SP of inner loop
        sp_values = {
            'sp1': mv_values['mv4'],
            'sp2': mv_values['mv5'],
            'sp3': mv_values['mv6'],
        }
    
        # 整理所有需要写入的数据
        data_to_write = {
            'dynamic_layer.pressure1': pressures['pressure1'],
            'dynamic_layer.pressure2': pressures['pressure2'],
            'dynamic_layer.pressure3': pressures['pressure3'],
            'dynamic_layer.preesure_weighted': pressure_weighted,
            'static_layer.OV1_test': ov_test_group['ov1_test'],
            'static_layer.OV2_test': ov_test_group['ov2_test'],
            'static_layer.OV3_test': ov_test_group['ov3_test'],
            'static_layer.OV1': ov_group['ov1'],
            'static_layer.OV2': ov_group['ov2'],
            'static_layer.OV3': ov_group['ov3'],
            'dynamic_layer.MV1': mv_values['mv1'],
            'dynamic_layer.MV2': mv_values['mv2'],
            'dynamic_layer.MV3': mv_values['mv3'],
            'dynamic_layer.MV4': mv_values['mv4'],
            'dynamic_layer.MV5': mv_values['mv5'],
            'dynamic_layer.MV6': mv_values['mv6'],
            'dynamic_layer.SP1': sp_values['sp1'],
            'dynamic_layer.SP2': sp_values['sp2'],
            'dynamic_layer.SP3': sp_values['sp3'],
            'dynamic_layer.IRV1': irv_values['irv1'],
            'dynamic_layer.IRV2': irv_values['irv2'],
            'dynamic_layer.IRV3': irv_values['irv3'],
            
        }
    
        self.write(data_to_write)

       
    def get_pressure(self):

        for i in range(3):
            self.Y_past[i][1:] = self.Y_past[i][:-1]
            self.Y_past[i][0] = self.pressures[i]

            self.U_past[i][1:] = self.U_past[i][:-1]
            self.U_past[i][0] = self.read_value(f'dynamic_layer.MV{i+1}')
            

        self.pressures = [
            (np.dot(self.U_past[i][0+self.models[i]["delay"]:2+self.models[i]["delay"]].flatten(),
                    np.array(self.models[i]["B"][1:])) -
             np.dot(self.Y_past[i].flatten(),
                    np.array(self.models[i]["A"][1:])))
            for i in range(3)
        ]
        
        for i in range(3):        
            load = self.pressures[i] / self.models[i]["full_ps"] * 100
            self.models[i]["gain"] = self.models[i]["func"](load)

        pressure1, pressure2, pressure3 = self.pressures
        
        pressure1 = pressure1 / self.models[0]["gain0"] * self.models[0]["gain"]
        pressure2 = pressure2 / self.models[1]["gain0"] * self.models[1]["gain"]
        pressure3 = pressure3 / self.models[2]["gain0"] * self.models[2]["gain"]

        pressure_weighted = pressure1/3 + pressure2/3 + pressure3/3

        self.write({'dynamic_layer.pressure1': pressure1})
        self.write({'dynamic_layer.pressure2': pressure2})
        self.write({'dynamic_layer.pressure3': pressure3})
        self.write({'dynamic_layer.pressure_weighted': pressure_weighted})
        
        sum_coal = self.U_past[0][0] + self.U_past[1][0] + self.U_past[2][0]
        sum_coal = sum_coal.item()

               
        # self.write({'static_layer.Coal_consume': sum_coal})
        self.write({'static_layer.OBF': sum_coal})

        print(f"Pressure1: {pressure1}, Pressure2: {pressure2}, Pressure3: {pressure3}")
        print(f"Weighted Average Pressure: {pressure_weighted}")

        
        

    def get_sp(self):
        # Read the values of MV and OV.
        mv_values = {
            'mv4': self.read_value('dynamic_layer.MV4'),
            'mv5': self.read_value('dynamic_layer.MV5'),
            'mv6': self.read_value('dynamic_layer.MV6')
        }
        ov_test_group = {
            'ov1_test': self.read_value('static_layer.OV1_test'),
            'ov2_test': self.read_value('static_layer.OV2_test'),
            'ov3_test': self.read_value('static_layer.OV3_test')
        }
        ov_group = {
            'ov1': self.read_value('static_layer.OV1'),
            'ov2': self.read_value('static_layer.OV2'),
            'ov3': self.read_value('static_layer.OV3')
        }
    
        # Update OV values
        # for key in ov_test_group:
        #     old_value = getattr(self, f"{key}_old", 0)  # 获取历史值
        #     ov_test_group[key] = -old_value * self.low_pass_a + ov_test_group[key] * self.low_pass_b
        #     setattr(self, f"{key}_old", ov_test_group[key])  # 更新历史值
    
        # Calculate SP values
        sp_values = {
            'dynamic_layer.SP1': mv_values['mv4'],
            'dynamic_layer.SP2': mv_values['mv5'],
            'dynamic_layer.SP3': mv_values['mv6']
        }
        
        irv_values = {
            'dynamic_layer.IRV1': ov_test_group['ov1_test'] + ov_group['ov1'],
            'dynamic_layer.IRV2': ov_test_group['ov2_test'] + ov_group['ov2'],
            'dynamic_layer.IRV3': ov_test_group['ov3_test'] + ov_group['ov3'],
        }
    
        # Write SP values
        self.write(sp_values)
        self.write(irv_values)

        
    def done(self):
        self.get_pressure()
        self.get_sp()


if __name__ == '__main__':
    task = SampleTask('127.0.0.1', 9999)
    task.initial_state()
    task.run()

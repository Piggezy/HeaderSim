Get the latest installation packages for TaiJi MPC, TaiJi RTO, and OPCGate at the following URL:
https://github.com/ymwang78/TaijiControl/releases

